package application.adminClient;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RegularClient 
{
	@FXML
	private TextField firstName;
	
	@FXML
	private TextField lastName;
	
	@FXML
	private TextField passport;
	
	@FXML
	private TextField gender;
	
	@FXML
	private TextField address;
	
	@FXML
	private TextField nationality;
	
	@FXML
	private TextField eye;
	
	@FXML
	private TextField height;
	
	@FXML
	private TextField phone;
	
	@FXML
	private TextField mail;
	
	@FXML
	private TextField password;
	
	@FXML
	private TextField center;
	
	public void login(ActionEvent ae) throws Exception
	{
		if (textUserName.getText().equals("user")&& textPassword.getText().equals("pass"))
		{
			labelStatus.setText("Login succesful");		
			Stage primaryStage= new Stage();
			FXMLLoader loader = new FXMLLoader(); 
			loader.setLocation(getClass().getResource("MainFXML.fxml")); 
			Parent root= loader.load(); 
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		}
		else 
		{
			labelStatus.setText("Login failed");		
		}
	}
}
